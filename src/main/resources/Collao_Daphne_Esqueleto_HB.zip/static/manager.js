// //Modal
// var myModal = document.getElementById('myModal')
// var myInput = document.getElementById('myInput')

// myModal.addEventListener('shown.bs.modal', function () {
//     myInput.focus()
// })

Vue.createApp({
    data() {
        return {
            clientsApiUrl: 'http://localhost:8080/clients',
            clients: [],
            jsonClients: [],

            // V-Model addClient
            clientFirstName: "",
            clientLastName: "",
            clientEmail: "",
            
            //opcion 1
            editFirstName: "",
            editLastName: "",
            editEmail: "",

            //opcion 2
            // editedClients: {
            //     editFirstName: "",
            //     editLastName: "",
            //     editEmail: "",
            // },

            // Show/hide
            showRest: false,
        }
    },
    created() {
        axios.get(this.clientsApiUrl)
            .then(datos => {
                this.clients = datos.data._embedded.clients
                this.jsonClients = datos.data
                //prueba
                this.editFirstName = this.clients.firstName
                this.lastName = this.clients.lastName
                this.email = this.clients.email  
            })
        },
        
        methods: {
        addClient() {
            axios.post(this.clientsApiUrl, {
                firstName: this.clientFirstName,
                lastName: this.clientLastName,
                email: this.clientEmail,
            })
                .then(response => {
                    console.log(response),
                    window.location.reload();
                })
                .catch(error => console.log(error))
            },

        removeClient(client){
            axios.delete(client)
            .then(response =>{
                console.log(response);
                window.location.reload()
            })
        },

        editClient(client){
            axios.put(client)
            .then(response =>{
                console.log(response);
                window.location.reload()
            })                
            .catch(error => console.log(error))
        },
    },

    computed: {
    }
}).mount('#app')
